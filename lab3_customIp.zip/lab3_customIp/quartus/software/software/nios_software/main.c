#include "system.h"
//typedef enum {false, true} bool;

//typedef enum {false, true} bool;
	unsigned long *ledPtr= (unsigned long *) LEDS_BASE;
	unsigned long *keyptr = (unsigned long *) KEY1_BASE;
	//unsigned short *ledsBase_ptr = (unsigned short *) LEDS_BASE;
	unsigned long *addr = (unsigned long *) 0;
	/* unsigned long *addr1;
	unsigned long *addr2;
	unsigned long *addr3; */
	unsigned long ledVal = 0;
	unsigned long keyVal;
	unsigned short count = 0;

void main()
{
	writeData(4);
	*ledPtr = ledVal;
	addr = 0;
	while (1){
		keyVal = *keyptr;


		while((keyVal) == 1){
			keyVal = *keyptr;
		}
		while((keyVal) == 0){
			while (count < 1){
				ledVal = 0;

				if (ramConfidenceTest(addr, 4) == 1){
					ledVal = 255;
				}
				else{
					ledVal = 0;
				}
				count++;
			}
			keyVal = *keyptr;
			*ledPtr = ledVal;
			count = 0;
		}

	}
}


int ramConfidenceTest(unsigned long *ptr, int numBytesToCheck){
 //for loop that iterates though addresses and checks them (num bytes = the amount of bytes being checked)
	int i = 0;
	//int c = 0;
	int b = 1;
	while(i < numBytesToCheck){
		if (*ptr == i){
			i++;
			ptr++;
			continue;
		}
		else{
			b = 0;
			break;
		}
	}
	if (b == 1){
		return 1;
	}
	else{
		return 0;
	}
}


void writeData(int times){
	int i = 0;
	while (times > i){
		*addr = i;
		i++;
		addr++;
		//times--;
	}
}
